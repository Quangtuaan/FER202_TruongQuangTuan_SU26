import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Alert,
  Badge,
  Button,
  Card,
  Col,
  Container,
  Form,
  Nav,
  Navbar,
  Row,
  Spinner,
  Table,
  Toast,
  ToastContainer,
} from 'react-bootstrap';
import { useAuth } from '../context/AuthContext';
import { userApi } from '../api/userApi';
import UserForm from '../components/UserForm';
import ConfirmDialog from '../components/ConfirmDialog';

function UsersPage() {
  const { currentUser, logout } = useAuth();

  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const [search, setSearch] = useState('');
  const [filterRole, setFilterRole] = useState('');

  const [showForm, setShowForm] = useState(false);
  const [editUser, setEditUser] = useState(null);
  const [formLoading, setFormLoading] = useState(false);
  const [formError, setFormError] = useState('');

  const [deleteTarget, setDeleteTarget] = useState(null);
  const [deleteLoading, setDeleteLoading] = useState(false);

  const [toast, setToast] = useState(null);

  const canCreateOrEdit =
    currentUser?.role === 'Admin' || currentUser?.role === 'Manager';

  const canDelete = currentUser?.role === 'Admin';

  const canToggleStatus =
    currentUser?.role === 'Admin' || currentUser?.role === 'Manager';

  const showToast = (message, variant = 'success') => {
    setToast({
      message,
      variant,
    });
  };

  const fetchUsers = useCallback(async () => {
    setLoading(true);
    setError('');

    try {
      const params = {};

      if (filterRole) {
        params.role = filterRole;
      }

      const { data } = await userApi.getAll(params);
      setUsers(data);
    } catch (err) {
      setError(err.message || 'Không tải được danh sách người dùng.');
    } finally {
      setLoading(false);
    }
  }, [filterRole]);

  useEffect(() => {
    fetchUsers();
  }, [fetchUsers]);

  const filteredUsers = useMemo(() => {
    const keyword = search.toLowerCase().trim();

    if (!keyword) {
      return users;
    }

    return users.filter((u) => {
      return (
        u.fullName?.toLowerCase().includes(keyword) ||
        u.email?.toLowerCase().includes(keyword) ||
        u.phone?.includes(keyword)
      );
    });
  }, [users, search]);

  const handleAdd = () => {
    setEditUser(null);
    setFormError('');
    setShowForm(true);
  };

  const handleEdit = (user) => {
    setEditUser(user);
    setFormError('');
    setShowForm(true);
  };

  const handleSubmit = async (formData) => {
    setFormLoading(true);
    setFormError('');

    try {
      if (editUser) {
        await userApi.update(editUser.id, {
          ...editUser,
          ...formData,
        });

        showToast('Cập nhật người dùng thành công!');
      } else {
        await userApi.create(formData);
        showToast('Thêm người dùng thành công!');
      }

      setShowForm(false);
      setEditUser(null);
      fetchUsers();
    } catch (err) {
      setFormError(err.message || 'Lưu dữ liệu thất bại.');
    } finally {
      setFormLoading(false);
    }
  };

  const handleToggleStatus = async (user) => {
    const newStatus = user.status === 'active' ? 'inactive' : 'active';

    try {
      await userApi.patch(user.id, {
        status: newStatus,
      });

      setUsers((prev) =>
        prev.map((u) =>
          u.id === user.id
            ? {
                ...u,
                status: newStatus,
              }
            : u
        )
      );

      showToast('Cập nhật trạng thái thành công!');
    } catch (err) {
      showToast('Cập nhật trạng thái thất bại.', 'danger');
    }
  };

  const handleDeleteConfirm = async () => {
    if (!deleteTarget) return;

    setDeleteLoading(true);

    try {
      await userApi.remove(deleteTarget.id);

      showToast(`Đã xóa "${deleteTarget.fullName}" thành công!`);
      setDeleteTarget(null);
      fetchUsers();
    } catch (err) {
      showToast('Xóa người dùng thất bại.', 'danger');
      setDeleteTarget(null);
    } finally {
      setDeleteLoading(false);
    }
  };

  const renderRoleBadge = (role) => {
    if (role === 'Admin') return <Badge bg="danger">Admin</Badge>;
    if (role === 'Manager') return <Badge bg="warning">Manager</Badge>;
    return <Badge bg="secondary">User</Badge>;
  };

  const renderStatusBadge = (status) => {
    if (status === 'active') return <Badge bg="success">Active</Badge>;
    return <Badge bg="dark">Inactive</Badge>;
  };

  return (
    <>
      <Navbar bg="dark" variant="dark" expand="lg">
        <Container>
          <Navbar.Brand>User Manager</Navbar.Brand>

          <Nav className="ms-auto d-flex align-items-center gap-3">
            <span className="text-white">
              {currentUser?.fullName} ({currentUser?.role})
            </span>

            <Button variant="outline-light" size="sm" onClick={logout}>
              Đăng xuất
            </Button>
          </Nav>
        </Container>
      </Navbar>

      <Container className="py-4">
        <Card className="shadow-sm">
          <Card.Body>
            <Row className="mb-3 align-items-center">
              <Col md={4}>
                <h4 className="mb-0">Danh sách người dùng</h4>
              </Col>

              <Col md={3}>
                <Form.Control
                  type="text"
                  placeholder="Tìm tên, email, SĐT..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                />
              </Col>

              <Col md={3}>
                <Form.Select
                  value={filterRole}
                  onChange={(e) => setFilterRole(e.target.value)}
                >
                  <option value="">Tất cả vai trò</option>
                  <option value="Admin">Admin</option>
                  <option value="Manager">Manager</option>
                  <option value="User">User</option>
                </Form.Select>
              </Col>

              <Col md={2} className="text-end">
                {canCreateOrEdit && (
                  <Button variant="primary" onClick={handleAdd}>
                    + Thêm
                  </Button>
                )}
              </Col>
            </Row>

            {error && <Alert variant="danger">{error}</Alert>}

            {loading ? (
              <div className="text-center py-5">
                <Spinner animation="border" />
                <div className="mt-2">Đang tải dữ liệu...</div>
              </div>
            ) : (
              <Table bordered hover responsive className="align-middle">
                <thead className="table-dark">
                  <tr>
                    <th>ID</th>
                    <th>Họ tên</th>
                    <th>Email</th>
                    <th>SĐT</th>
                    <th>Vai trò</th>
                    <th>Trạng thái</th>
                    <th>Ngày tạo</th>
                    <th style={{ width: '220px' }}>Hành động</th>
                  </tr>
                </thead>

                <tbody>
                  {filteredUsers.length === 0 ? (
                    <tr>
                      <td colSpan="8" className="text-center text-muted">
                        Không có dữ liệu.
                      </td>
                    </tr>
                  ) : (
                    filteredUsers.map((user) => (
                      <tr key={user.id}>
                        <td>{user.id}</td>
                        <td>{user.fullName}</td>
                        <td>{user.email}</td>
                        <td>{user.phone}</td>
                        <td>{renderRoleBadge(user.role)}</td>
                        <td>{renderStatusBadge(user.status)}</td>
                        <td>{user.createdAt}</td>
                        <td>
                          <div className="d-flex gap-2 flex-wrap">
                            {canCreateOrEdit && (
                              <Button
                                variant="outline-primary"
                                size="sm"
                                onClick={() => handleEdit(user)}
                              >
                                Sửa
                              </Button>
                            )}

                            {canToggleStatus && (
                              <Button
                                variant="outline-warning"
                                size="sm"
                                onClick={() => handleToggleStatus(user)}
                              >
                                Đổi trạng thái
                              </Button>
                            )}

                            {canDelete && (
                              <Button
                                variant="outline-danger"
                                size="sm"
                                onClick={() => setDeleteTarget(user)}
                              >
                                Xóa
                              </Button>
                            )}

                            {!canCreateOrEdit && !canDelete && (
                              <span className="text-muted">Chỉ xem</span>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </Table>
            )}
          </Card.Body>
        </Card>
      </Container>

      <UserForm
        show={showForm}
        onHide={() => setShowForm(false)}
        onSubmit={handleSubmit}
        user={editUser}
        loading={formLoading}
        error={formError}
      />

      <ConfirmDialog
        show={!!deleteTarget}
        title="Xác nhận xóa"
        message={`Bạn có chắc muốn xóa "${deleteTarget?.fullName}" không?`}
        onCancel={() => setDeleteTarget(null)}
        onConfirm={handleDeleteConfirm}
        loading={deleteLoading}
      />

      <ToastContainer position="top-end" className="p-3">
        <Toast
          show={!!toast}
          onClose={() => setToast(null)}
          delay={2500}
          autohide
          bg={toast?.variant || 'success'}
        >
          <Toast.Body className="text-white">{toast?.message}</Toast.Body>
        </Toast>
      </ToastContainer>
    </>
  );
}

export default UsersPage;